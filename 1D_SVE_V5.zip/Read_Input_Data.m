%% Read Input Data %%
data = xlsread('Input_Data_SVE.xlsx');

b = 0; Z1 = 0; Z2 = 0; a = 0; D = 0;

% Flags
flag_hydrograph = data(1,1);
flag_outlet = data(2,1);
flag_friction = data(3,1);
flag_section = data(4,1);

if flag_hydrograph ~= 1
    % Hydrograph
    Tp = data(1,4);
    Qb = data(2,4);
    Beta = data(3,4);
    Qp = data(4,4);
else
    % Input Hydrograph
     time_ = data(8:end,3);
     Qe1_ = data(8:end,4);
     Qe1 = zeros(size(Qe1_,1) - sum(isnan(Qe1_)),1);
     time = zeros(size(time_,1) - sum(isnan(time_)),1);
     % Taking away nans
     for i = 1:length(Qe1)
        if isnan(Qe1_(i)) || isnan(time_(i))
            break
        else
            Qe1(i,1) = Qe1_(i,1);
            time(i,1) = time_(i,1);
        end
     end
     clear Qe1_ time_
end

% Outlet
if flag_outlet ~=1
    h_0_wave = data(1,7);
    H_0_wave = data(2,7); 
    L_wave = data(3,7);
    T_wave = data(4,7);
end

% Section
if flag_section == 1
    b = data(1,10);
    Z1 = data(2,10);
    Z2 = data(3,10);
elseif flag_section == 2
    D = data(1,13);
elseif flag_section == 3
    a = data(3,13);
else
    % Read HP estimator data
    [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr, x_cross, y_cross] = HP_estimator;
    irr_table = [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];   
end

% General Data
L = data(9,1);
Nx = data(10,1);
el = data(11,1);
g = data(12,1);
nm = data(13,1);
I0 = data(14,1); 
tf = data(15,1);
dt = data(16,1);
animation_time = data(17,1);

% Contraint at observed flow
if flag_hydrograph == 1
    if max(time) ~= tf
        z = round(tf - max(time),0);
        for i = 1:z
            Qe1(end + 1,1) = 0;
            time(end+1,1) = time(end,1) + 1;
        end
    end
end


