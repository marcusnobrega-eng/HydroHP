%%% Saint Venant Equations Solver %%%
% Developer: Marcus Nobrega Gomes Junior
% 4/10/2022
% Solution of SVE for given cross-section functions of Area, Perimeter, and
% top Width
%%% Still misses the introduction of Beta in F2 (check the paper)

%% Pre-Processing
clear all
clc
warning('off')

% Reading the Input Data
Read_Input_Data

% Inflow Hydrograph
% flag_hydrograph = 2; % If 1, enter the hydrograph, if 2, model using nash function
% 1st option - Enter Qe1 and Time below
if flag_hydrograph == 1
    % We already read the hydrograph in Read_Input_Data file
else
    % 2nd option - Model the hydrograph using a nash function
    %%% Q(t) = Qb(t) + (Qp(t) - Qb(t))*(t/TP*EXP(1 - t/TP))^Beta
    Inflow_Hydrograph_fun = @(t)(Qb + (Qp - Qb).*(t/(Tp*60).*exp(1 - (t)/(Tp*60))).^Beta);
    time = [0 tf/60]'; % begin and end in minutes
end

% Outlet Boundary Condition
% flag_outlet = 1; % 1 = normal depth, 2 = stage_hydrograph
if flag_outlet ~= 1
    %%% Wave Properties for Outlet Stage Hydrograph
        x_wave = L_wave/1; % point position in wave x direction;
        k_wave = 2*pi/L_wave;
        sigma_wave = 2*pi./(T_wave*3600);
        h_wave_function = @(t)(h_0_wave + H_0_wave/2.*cos(k_wave.*x_wave - sigma_wave*t));
end

% Time Calculations
time = time*60; % time in seconds
[a1,~] = size(time);
tt_h = time(a1,1); % end of hydrograph in seconds
tt = min(tf,tt_h)*60; % End of simulation in seconds
Nt = tt/dt; % Number of time-steps
Nat = animation_time*60/dt; % Number of time-steps within an animation time
tint = linspace(0,tt/60,Nt); % Generate Nt points within 0 and tt(min)
if flag_hydrograph == 1
    Qe1int = max(interp1(time/60,Qe1(:,1),tint,'pchip'),0); % Interpolated flow % Não utilizar spline;
    % pchip, que corresponde ao Hermite cúbico, é uma opção preferível.
    % Assuming no negative flows
    Qe1int = Qe1int';
else
    Qe1int = Inflow_Hydrograph_fun(tint)';
end


% Channel Discretization
dx = L/(Nx-1); % Channel discretization length in meters

% Friction Data
flag_friction = 1; % If 1, Manning, otherwise DW

% Manning
nm = repmat(nm,Nx,1); % Bottom slope in m/m for all reaches
% Darcy Weisbach
f = 0; % not implemented

% Pre-allocating arrays
% Matrices
x = (0:dx:L)'; % x discretization in meters
y = zeros(Nx,Nt);
q1 = zeros(Nx,Nt);
q2 = zeros(Nx,Nt);
f1 = zeros(Nx,Nt);
f2 = zeros(Nx,Nt);
J2 = zeros(Nx,Nt);
q1_back = q1(1:(Nx-2),Nt);
q1_foward = zeros(Nx-2,Nt);
q2_back = zeros(Nx-2,Nt);
q2_foward = zeros(Nx-2,Nt);
f1_back = zeros(Nx-2,Nt);
f1_foward = zeros(Nx-2,Nt);
f2_back = zeros(Nx-2,Nt);
f2_foward = zeros(Nx-2,Nt);
J2_back = zeros(Nx-2,Nt);
J2_foward = zeros(Nx-2,Nt);
ybar = zeros(Nx,Nt);
Fr = zeros(Nx,Nt);
Cn = zeros(Nx,Nt);

%% Channel Data (Cross Section)
% Slope
I0 = repmat(I0,Nx,1); % Bottom slope in m/m for all reaches

% Intializing channel data
sm = 1e-12; % Small number
b = sm + b; Z1 = sm + Z1; Z2 = sm + Z2; D = sm + D; a = sm + a;
% flag_section - If 1, trapezoid, if 2, circular, if 3, paraboloid, if 4 - Irregular

% Invert Elevations
inv_el = zeros(Nx,1);
for i = 1:Nx
    if i == 1
        inv_el(i) = el;
    else
        inv_el(i) = inv_el(i-1) - (I0(i)*dx);
    end
end

% Geometrical Functions
syms b_ y_ Z1_ Z2_ Q_ I0_ D_ a_
dim_all = 1e-6*(y_ + Z1_ + Z2_ + a_ + D_ + b_);
if flag_section == 1
    B = b_ + y_*(Z1_ + Z2_) + + dim_all; % user defined function (top width)
    B_function = matlabFunction(B);
    P = b_ + y_*(sqrt(1 + Z1_^2) + sqrt(1 + Z2_^2)) + dim_all; % Perimeter Function % user defined function
    P_function = matlabFunction(P);
    A = (2*b_ + y_*(Z1_ + Z2_))*y_/2 + dim_all; % Area function % user defined function
    A_function = matlabFunction(A); % Function describing the area in terms of y
    centroid = y_ - int(A,y_)./A + dim_all; % 1st order momentum
    ybar_function = matlabFunction(centroid); % Function describing ybar in terms of y
end
if flag_section == 2
    % Circular Section
    theta = 2*acos(1 - 2.*y_./D_) + dim_all;
    B = D_.*sin(theta/2) ; % top width
    B_function = matlabFunction(B);
    P = theta.*D_/2 ; % perimeter
    P_function = matlabFunction(P);
    A = D_.^2/8.*(theta - sin(theta)) ; % area
    A_function = matlabFunction(A); % Function describing the area in terms of y
    Ybar = y_ - (D_.*(- cos(theta/2)/2 + 2.*sin(theta/2).^3./(3*(theta - sin(theta))))); % Very much attention here
    ybar_function = matlabFunction(Ybar);
end

if flag_section == 3
    % Parabolic Section
    % Area Function
    A = 4.*(y_.^3/2)./(3*sqrt(a_)) + dim_all; % m2
    A_function = matlabFunction(A); % Function describing the area in terms of y
    % Top Width
    B = 3/2.*A./y_ + dim_all; % m
    B_function = matlabFunction(B);
    % Hydraulic Perimeter
    P = dim_all + sqrt(y_)./sqrt(a_).*(sqrt(1 + 4*a_.*y_) + 1./(2*a_).*(log(2*sqrt(a_).*sqrt(y_) + sqrt(1 + 4*a_.*y_))));
    P_function = matlabFunction(P);
    Y_bar = y_ - 2/5*y_ + dim_all;
    ybar_function = matlabFunction(Y_bar);
end

if flag_section ~= 4
    %%%%%%% Hydraulic Radius %%%%%%%
    Rh = A/P; % Hydraulic Radius Function
    Rh_function = matlabFunction(Rh); % Function describing the hydraulic radius in terms of y
end

% Vlookup Function
Vlookup_eq = @(data,col1,val1,col2) data((find(data(:,col1)==val1,1,'first')),col2); %Vlookup function as Excel
Vlookup_l = @(data,col1,val1,col2) data((find(data(:,col1)<val1,1,'last')),col2); %Vlookup function as Excel]
Vlookup_g = @(data,col1,val1,col2) data((find(data(:,col1)>val1,1,'first')),col2); %Vlookup function as Excel
fv = 1 + 1e-4; % Factor to avoid fails in vlookup function

% Initial Guess
if flag_section == 1
    y0_guess = 1; 
elseif flag_section == 2
    y0_guess = D/2;
elseif flag_section == 3
    y0_guess = 1;
end

%% Initial Boundary Conditions
Q0 = Qe1int(1,1); % Flow at inlet section at time 0
if flag_outlet == 1
    if flag_friction == 1
        if flag_section ~= 4
            if Q0 == 0
                Q0 = sm; % Numerical Constraint                
            end
            y0 = uniformeM(nm,Q0,b,Z1,Z2,a,D,I0,P,A,y0_guess)   ; % normal depth using manning equation
                % More Initial Boundary Conditions for Area, Velocity, Perimeter and Rh
            A0 = A_function(D,Z1,Z2,a,b,y0); % Cross section area in m
            u0 = (Q0./A0)'; % Initial velocity in m/s
            P0 = P_function(D,Z1,Z2,a,b,y0); % Hydraulic perimeter in m
            Rh0 = A0./P0; % Hydraulic radius at time 0
            % Boundary Conditions
            y(:,1) = y0; % all sub-reaches with y0 at the beginning
            q1(:,1) = A0; % all sub-reaches with same area A0 at the beginning
            q2(:,1) = Q0; % Assuming permanent conditions at the beginning
            f1(:,1) = q2(:,1);
            % f2 depends on ybar
        else % Irregular Cross-Section
            % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
            % [   1,    2,     3,      4,    5,            6,          7,     8,      9,    10]
            col1 = 10; % Col with Q
            y0 = Vlookup_l(irr_table,col1,Q0*fv,1);
            A0 = Vlookup_l(irr_table,col1,Q0*fv,2);
            P0 = Vlookup_l(irr_table,col1,Q0*fv,3);
            Rh0 = Vlookup_l(irr_table,col1,Q0*fv,4);
            % Boundary Conditions
            y(:,1) = y0; % all sub-reaches with y0 at the beginning
            q1(:,1) = A0; % all sub-reaches with same area A0 at the beginning
            q2(:,1) = Q0; % Assuming permanent conditions at the beginning
            f1(:,1) = q2(:,1);
        end
    else
        % % normal depth using Darcy-Weisbach equation not implemented yet
    end
else
    steady_depth = uniformeM(nm,Q0,b,Z1,Z2,a,D,I0,P,A);
    y0(1:(Nx-1),1) = steady_depth(1:(Nx-1),1);
    % Stage Hydrograph Boundary Condition
    time_wave = 0; % time in seconds
    y0(Nx,1) = h_wave_function(time_wave);
    % More Initial Boundary Conditions for Area, Velocity, Perimeter and Rh
    A0 = A_function(D,Z1,Z2,a,b,y0); % Cross section area in m
    u0 = (Q0./A0)'; % Initial velocity in m/s
    P0 = P_function(D,Z1,Z2,a,b,y0); % Hydraulic perimeter in m
    Rh0 = A0./P0; % Hydraulic radius at time 0
    y(:,1) = y0(:,1); % all sub-reaches with y0 at the beginning
    q1(:,1) = A0(:,1); % all sub-reaches with same area A0 at the beginning
    q2(:,1) = Q0(:,1); % Assuming permanent conditions at the beginning
    f1(:,1) = q2(:,1);
    % f2 depends on ybar, we will calculate below
end

%%% State Space Format %%%
% dq/dt + dF/dx = S, we solve for A(x,t) and Q(x,t)
% q = [A Q]' = [q1 q2]'
% F [Q (Qv + gAybar]' = [q2 (q2^2)/q1 + g.q1.ybar]' = [f1 f2]'
% where ybar is the centroid depth from the top
% S = [0 gA(I0 - If)]'

% ybar = y - int(A(y)) / A(y) from y = 0 to y = y0
if flag_section ~= 4
    ybar = ybar_function(D,Z1,Z2,a,b,y0);
else
    % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
    % [   1,    2,     3,      4,    5,            6,          7,     8,      9,
    % ybar = y - ybar*
    %     ybar(:,1) =  Vlookup_leq(irr_table,col1,Q0*fv,1) - Vlookup_leq(irr_table,col1,Q0*fv,5);
    ybar(:,1) = Vlookup_l(irr_table,col1,Q0*fv,5);
end
f2(:,1) = q2(:,1).*abs(q2(:,1))./q1(:,1) + g*q1(:,1).*ybar(:,1);

% Friction S = [J1 J2]' with J1 = 0 and J2 calculated as follows:
if flag_friction == 1
    J2(:,1) = g*q1(:,1).*(I0(:) - q2(:,1).*abs(q2(:,1)).*nm(:)./(q1(:,1).^2.*Rh0.^(4/3))); % Manning
else
    J2(:,1) = g*q1(:,1).*(I0(:) - f*q2(:,1).*abs(q2(:,1))./((q1(:,1).^2).*8*g.*Rh0)); % Darcy
end

% Froude Number
if flag_section ~= 4
    Fr(:,1)=abs(q2(:,1)./q1(:,1))./((g*A_function(D,Z1,Z2,a,b,y0)./B_function(D,Z1,Z2,a,b,y0)).^0.5);% Número de Froude
else
    % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
    % [   1,    2,     3,      4,    5,            6,          7,     8,      9,
    A_f_irr = Vlookup_l(irr_table,col1,Q0*fv,2)*ones(length(q1(:,1)),1);
    B_f_irr = Vlookup_l(irr_table,col1,Q0*fv,9)*ones(length(q1(:,1)),1);
    Fr(:,1)=abs(q2(:,1)./q1(:,1))./((g*A_f_irr./B_f_irr).^0.5);% Número de Froude
end
% Courant Number
% Cn = c / (dx / dt), where c = v + sqrt(g.Hm), where Hm = A / B
if flag_section ~= 4
    Hm = A_function(D,Z1,Z2,a,b,y0)./B_function(D,Z1,Z2,a,b,y0);
    Cn(:,1)=(abs(q2(:,1)./q1(:,1))+(g*Hm).^0.5)/(dx/dt);% Courant Number
else
    Hm = A_f_irr./B_f_irr;
    Cn(:,1) = (abs(q2(:,1)./q1(:,1))+(g*Hm).^0.5)/(dx/dt);
end

% Depth in terms of Area function
% let c be the area in terms of Z1,Z2,b, and y, such that A(y) = c
% we want to solve y for A(y) = c

syms c_
if flag_section ~= 4
    fun_solve = (A - c_); % with c = area, we solve for y.
    options = optimoptions ('fsolve', 'Display', 'none','FunctionTolerance',1e-2,'MaxFunctionEvaluations',Nx*10);
end
if flag_section == 1
    % We have an analytical solution for this case
    z = solve(fun_solve,y_); % solving for y_ = y and c = A(y)
    h_function = matlabFunction(z); % h(A) = z;
else
    % Non-linear set of equations for circular pipe, we need to use fsolve
end
if flag_section ~= 4
    fun_solve = matlabFunction(fun_solve); % Transforming into an equation
end
%% Main Loop %%
n = 1; % initializing counter
tic % starts measuring time

for t = dt:dt:(tt - dt) % Main loop
    n = n + 1;
    percentage_courantnumber_outletflow = [t/(tt - dt)*100, max(Cn(:,n-1)), max(q2(:,n-1))]
    % Stop Program if Complex Number Occurs
    if imag(max(Cn(:,n-1))) > 0 || imag(max(q2(:,n-1)))
        error('Complex number possibly due to changing the regime from free flow to pressurized flow.')
    end
    %%%%% -  Boundary Conditions -  %%%%%
    %% Channel's begin (INLET)
    q1(1,n) = q1(2,n-1); % Area at section 1 is equals area of section 2 from previous time-step
    q2(1,n) = Qe1int(n,1); % Flow at section 1 is the inflow hydrograph

    % Interpolating All Values from I_rr_table using q1 as basis
    % Explanation: area is given in m2. P, Rh, and other variables are
    % in m. So we have a quadratically similar triangle relationship
    if flag_section == 4
        for mm = 1:(length(irr_table(1,:))-1)
            interp_base = q1(1,n); % Value that will be used for interpolation (area)
            area_smaller = Vlookup_l(irr_table,2,interp_base,2); % Smaller values
            area_larger = Vlookup_g(irr_table,2,interp_base,2); % Larger values
            col1 = 2; % Interpolating from area values
            var_inlet(mm,1,1) = Vlookup_l(irr_table,col1,interp_base,mm); % Smaller values
            var_inlet(mm,1,2) = Vlookup_g(irr_table,col1,interp_base,mm); % Larger values
            alfa_var_inlet(mm,1) = sqrt((interp_base - area_smaller)/(area_larger - area_smaller));
        end
    end

    if flag_section == 1 % Trapezoid or Rectangular
        if Z1 > 0 || Z2 > 0 % Trapezoidal channel
            y(1,n) = max(h_function(D,Z1,Z2,a,b,q1(1,n)')); % water depth in terms of area q1
            % In this previous function, we solve h = y in terms of A = q1 = c
        else
            y(1,n) = q1(1,n)/b; % water depth in terms of area q1 for rectangular channels
        end
    elseif flag_section > 1 % circular or paraboloid or irregular
        y0_guess = y(1,n-1);
        c = q1(1,n)*fv;  % WEIRDO. I HAVE TO CHECK IT OUT ... ISNT IT (n-1)?
        if flag_section ~= 4
            fun = @(y_)fun_solve(D,Z1,Z2,a,b,c,y_);
            y(1,n) = fsolve(fun,y0_guess,options); % non-linear solver
        else % Irregular section
            % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
            % [   1,    2,     3,      4,    5,            6,          7,     8,      9,
            col1 = 2; % Col with A
            col_var = 1;
            % Var* = Var(-) + alfa*(Var(+) - Var(-))
            y(1,n) = var_inlet(col_var,1,1) + alfa_var_inlet(col_var,1)*(var_inlet(col_var,1,2) - var_inlet(col_var,1,1));
            %             y(1,n) = Vlookup_leq(irr_table,col1,c,1);
        end
    end
    % ybar
    if flag_section ~= 4
        ybar(1,n) = ybar_function(D,Z1,Z2,a,b,y(1,n));
        % f1 and f2
        f1(1,n) = q2(1,n);
        f2(1,n) = q2(1,n).*abs(q2(1,n))./q1(1,n) + g*q1(1,n).*ybar(1,n);
        % Hydraulic Radius
        Rh_inlet = Rh_function(D,Z1,Z2,a,b,y(1,n));
        % Friction
        if flag_friction == 1
            J2(1,n) = g*q1(1,n).*(I0(1) - q2(1,n).*abs(q2(1,n)).*nm(1).^2./(q1(1,n).^2*Rh_inlet.^(4/3))); % Manning
        else
            J2(1,n) = (I0(1) - f*q2(1,n).*abs(q2(1,n))./((q1(1,n).^2)*8*g.*Rh_inlet));
        end
        % Froude
        Fr(1,n)=abs(q2(1,n)./q1(1,n))./((g*A_function(D,Z1,Z2,a,b,y(1,n))./B_function(D,Z1,Z2,a,b,y(1,n)))^0.5);% Número de Froude
        % Courant
        Hm = A_function(D,Z1,Z2,a,b,y(1,n))./B_function(D,Z1,Z2,a,b,y(1,n));
        Cn(1,n)=(abs(q2(1,n)./q1(1,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
    else
        % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
        % [   1,    2,     3,      4,    5,            6,          7,  8,      9,  10]
        col1 = 2; % Col with A
        col_var = 5;
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        ybar(1,n) = var_inlet(col_var,1,1) + alfa_var_inlet(col_var,1)*(var_inlet(col_var,1,2) - var_inlet(col_var,1,1));
        % f1 and f2
        f1(1,n) = q2(1,n);
        f2(1,n) = q2(1,n).*abs(q2(1,n))./q1(1,n) + g*q1(1,n).*ybar(1,n);
        % Hydraulic Radius
        col_var = 4;
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        Rh_inlet = var_inlet(col_var,1,1) + alfa_var_inlet(col_var,1)*(var_inlet(col_var,1,2) - var_inlet(col_var,1,1));
        % Friction
        if flag_friction == 1
            col_var = 6;
            % Var* = Var(-) + alfa*(Var(+) - Var(-))
            nm(1) = var_inlet(col_var,1,1) + alfa_var_inlet(col_var,1)*(var_inlet(col_var,1,2) - var_inlet(col_var,1,1));
            if isnan(nm(1,1))
                nm = irr_table(2,6)*ones(length(q1(:,1)),1);
            end
            J2(1,n) = g*c.*(I0(1) - q2(1,n).*abs(q2(1,n)).*nm(1).^2./(c.^2*Rh_inlet.^(4/3))); % Manning
        else
            J2(1,n) = (I0(1) - f*q2(1,n).*abs(q2(1,n))./((q1(1,n).^2)*8*g.*Rh_inlet));
        end
        % Froude
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        A_f_irr = q1(1,n);
        col_var = 9;
        B_f_irr = var_inlet(col_var,1,1) + alfa_var_inlet(col_var,1)*(var_inlet(col_var,1,2) - var_inlet(col_var,1,1));
        %         B_f_irr = Vlookup_leq(irr_table,col1,c,9);
        Fr(1,n) = abs(q2(1,n)./q1(1,n))./((g*A_f_irr./B_f_irr)^0.5);% Número de Froude
        % Courant
        Hm = A_f_irr./B_f_irr;
        Cn(1,n) = (abs(q2(1,n)./q1(1,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
    end

    %% Right side of the channel (outlet)
    if flag_outlet == 1 % Normal Depth
        q1(Nx,n) = q1(Nx-1,n-1); % Boundary Condition
        % Interpolating All Values from I_rr_table using q1 as basis
        % Explanation: area is given in m2. P, Rh, and other variables are
        % in m. So we have a quadratically similar triangle relationship
        if flag_section == 4
            for mm = 1:(length(irr_table(1,:))-1)
                interp_base = q1(Nx,n); % Value that will be used for interpolation (area)
                area_smaller = Vlookup_l(irr_table,2,interp_base,2); % Smaller values
                area_larger = Vlookup_g(irr_table,2,interp_base,2); % Larger values
                col1 = 2; % Interpolating from area values
                var_outlet(mm,1,1) = Vlookup_l(irr_table,col1,interp_base,mm); % Smaller values
                var_outlet(mm,1,2) = Vlookup_g(irr_table,col1,interp_base,mm); % Larger values
                alfa_var_outlet(mm,1) = sqrt((interp_base - area_smaller)/(area_larger - area_smaller));
            end
        end
        if flag_section == 1
            q1(Nx,n) = q1(Nx-1,n-1); % Area of outlet is the area of previous cell at previous time-step
            if Z1 > 0 || Z2 > 0
                y(Nx,n) = max(h_function(D,Z1,Z2,a,b,q1(Nx,n)')); % water depth in terms of area q1
            else
                y(Nx,n) = q1(Nx,n)/b; % water depth in terms of area q1 for rectangular channels
            end
        elseif flag_section >= 2 % circular or paraboloid or irregular
            % If we do not have an stage-hydrograph boundary condition
            y0_guess = y(Nx,n-1);
            if flag_section ~= 4
                fun = @(y_)fun_solve(D,Z1,Z2,a,b,c,y_);
                y(Nx,n) = fsolve(fun,y0_guess,options); % non-linear solver
            else
                % [y_table, A, P, Rh, y_bar, n_med, Beta, v, B, Q]
                % [   1,    2, 3, 4,    5,    6,      7,  8,  9, 10]
                col_var = 1;
                % Var* = Var(-) + alfa*(Var(+) - Var(-))
                y(Nx,n) = var_outlet(col_var,1,1) + alfa_var_outlet(col_var,1)*(var_outlet(col_var,1,2) - var_outlet(col_var,1,1));
            end
        end
    else
        % Stage Hydrograph Boundary Condition
        time_wave = n*dt; % time in seconds
        y(Nx,n) = h_wave_function(time_wave);
        q1(Nx,n) = A_function(D,Z1,Z2,a,b,y(Nx,n));
        %         q1(Nx,n) = q1(Nx-1,n-1)
    end
    % Hydraulic Radius
    if flag_section ~= 4
        Rh_outlet = Rh_function(D,Z1,Z2,a,b,y(Nx,n));
    else
        % [y_table, A, P, Rh, y_bar, n_med, Beta, v, B, Q]
        % [   1,    2, 3, 4,    5,    6,      7,  8,  9, 10]
        %         col1 = 2; % Col with A
        %         Rh_outlet = Vlookup_l(irr_table,col1,c,4);
        col_var = 4;
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        Rh_outlet = var_outlet(col_var,1,1) + alfa_var_outlet(col_var,1)*(var_outlet(col_var,1,2) - var_outlet(col_var,1,1));
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        col_var = 6;
        nm(end,1) = var_inlet(col_var,1,1) + alfa_var_inlet(col_var,1)*(var_inlet(col_var,1,2) - var_inlet(col_var,1,1));
    end
    if flag_friction == 1
        if flag_outlet == 1
            u = (1./nm(Nx)).*Rh_outlet^(2/3)*I0(Nx)^0.5; % Normal depth at the outlet
            flow_dir = 1;
        else
            depth_dif = y(Nx-1,n-1) + inv_el(Nx-1) - y(Nx,n) - inv_el(Nx); % Diference in wse
            out_slope = abs(depth_dif)/dx; % Flow slope at the outlet
            u = (1./nm(Nx)).*Rh_outlet^(2/3)*out_slope^0.5; % Normal depth at the outlet
            if depth_dif > 0
                flow_dir = 1; % Flowing towards the outlet
            else
                flow_dir = -1; % Flowing to inside of the channel
            end
        end
    else
        u = sqrt(8*g*Rh_outlet*I0(Nx)/f); % outlet velocity
    end
    % Outlet Flow
    q2(Nx,n) = q1(Nx,n)*u*flow_dir; % Area x Velocity
    if isnan(q2(Nx,n))
        ttt = 1;
    end
    % ybar
    if flag_section ~= 4
        ybar(Nx,n) = ybar_function(D,Z1,Z2,a,b,y(Nx,n));
    else
        % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
        % [   1,    2,     3,      4,    5,            6,          7,  8,      9,  10]
        % ybar = y - ybar*
        col1 = 2; % A
        %         ybar(Nx,n) =  Vlookup_leq(irr_table,col1,c,1) - Vlookup_leq(irr_table,col1,c,5);
        ybar(Nx,n) = Vlookup_l(irr_table,col1,c,5);
        col_var = 5;
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        ybar(Nx,n) = var_outlet(col_var,1,1) + alfa_var_outlet(col_var,1)*(var_outlet(col_var,1,2) - var_outlet(col_var,1,1));
    end
    % f1 and f2
    f1(Nx,n) = q2(Nx,n); % f1 - Area
    f2(Nx,n) = q2(Nx,n).*abs(q2(Nx,n))./q1(Nx,n) + g*q1(Nx,n).*ybar(Nx,n); % f2 = (Qv + gAy_bar)
    % J2
    % Friction
    if flag_friction == 1
        J2(Nx,n) = g*q1(Nx,n).*(I0(Nx) - q2(Nx,n).*abs(q2(Nx,n)).*nm(Nx)^2./(q1(Nx,n).^2*Rh_outlet.^(4/3))); % Manning --> gA*(I0 - If), If = n^2*Q*abs*Q)/(Rh^(4/3)*A^2)
    else
        J2(Nx,n) = g*q1(Nx,n).*(I0(Nx) - f*q2(:,n).*abs(q2(Nx,n))./((q1(Nx,n).^2)*8*g*Rh_outlet));
    end
    % Froude
    if flag_section ~= 4
        Fr(Nx,n)=abs(q2(Nx,n)./q1(Nx,n))./((g*A_function(D,Z1,Z2,a,b,y(Nx,n))./B_function(D,Z1,Z2,a,b,y(Nx,n)))^0.5);% Número de Froude
        % Courant
        Hm = A_function(D,Z1,Z2,a,b,y(Nx,n))./B_function(D,Z1,Z2,a,b,y(Nx,n));
        Cn(Nx,n)=(abs(q2(Nx,n)./q1(Nx,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
    else
        % Froude
        % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
        % [   1,    2,     3,      4,    5,            6,          7,  8,      9,  10]
        col1 = 2; % Col with A
        A_f_irr = c;
        col_var = 9;
        % Var* = Var(-) + alfa*(Var(+) - Var(-))
        B_f_irr = var_outlet(col_var,1,1) + alfa_var_outlet(col_var,1)*(var_outlet(col_var,1,2) - var_outlet(col_var,1,1));
        %         B_f_irr = Vlookup_l(irr_table,col1,c,9);
        Fr(Nx,n) = abs(q2(Nx,n)./q1(Nx,n))./((g*A_f_irr./B_f_irr)^0.5);% Número de Froude
        % Courant
        Hm = A_f_irr./B_f_irr;
        Cn(Nx,n)=(abs(q2(1,n)./q1(1,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
    end

    %% Main Loop for Non Boundary Cells from 2 to (Nx - 1)
    % vectorized calculations
    q1_back = q1(1:(Nx-2),(n-1));
    q1_foward = q1(3:(Nx),(n-1));
    q2_back = q2(1:(Nx-2),(n-1));
    q2_foward = q2(3:(Nx),(n-1));
    f1_back = f1(1:(Nx-2),(n-1));
    f1_foward = f1(3:(Nx),(n-1));
    f2_back = f2(1:(Nx-2),(n-1));
    f2_foward = f2(3:(Nx),(n-1));
    J2_back = J2(1:(Nx-2),(n-1));
    J2_foward = J2(3:(Nx),(n-1));

    x_i = 2:(Nx-1); % vector for interior sections varying from 2 to (Nx - 1)
    % Lax-Friedrichs Method
    % Given an hyperbolic partial derivative system of equations described
    % by:
    % pq/pt + pF/px - S = 0, where p is the partial derivative, one can
    % solve this equation by performing a foward discretization for q and a
    % central discretization for F. Moreover, S = (Sback + Sfoward)/2
    % Expliciting the system of equations for q1, it follows that

    q1(x_i,n) = 0.5.*(q1_foward + q1_back) - 0.5*dt/dx*(f1_foward - f1_back); %% attention here in f1foward
    q2(x_i,n) = 0.5*(q2_foward + q2_back) - 0.5*dt/dx*(f2_foward - f2_back) + 0.5*dt*(J2_back + J2_foward);

    % Interpolating All Values from I_rr_table using q1 as basis
    if flag_section == 4
        for mm = 1:(length(irr_table(1,:))-1)
            for hh = 1:length(x_i)
                interp_base = q1(hh+1,n); % Value that will be used for interpolation (area)
                area_smaller = Vlookup_l(irr_table,2,interp_base,2); % Smaller values
                area_larger = Vlookup_g(irr_table,2,interp_base,2); % Larger values
                col1 = 2; % Interpolating from area values
                var_middle(mm,hh,1) = Vlookup_l(irr_table,col1,interp_base,mm); % Smaller values
                var_middle(mm,hh,2) = Vlookup_g(irr_table,col1,interp_base,mm); % Larger values
                alfa_var_middle(mm,hh,1) = sqrt((interp_base - area_smaller)/(area_larger - area_smaller));
            end
        end
    end

    if flag_section == 1
        if Z1>0 || Z2>0
            y(x_i,n) = max(h_function(D,Z1,Z2,a,b,q1(x_i,n)')); % water depth in terms of area q1
        else
            y(x_i,n)=q1(x_i,n)/b;
        end
    elseif flag_section > 1
        y0_guess = y(x_i,n-1);
        c = q1(x_i,n)*fv; % It has to be a line vector (area)
        if flag_section ~= 4
            fun = @(y_)fun_solve(D,Z1,Z2,a,b,c,y_);
            y(x_i,n) = fsolve(fun,y0_guess,options); % non-linear solver
        else
            % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
            % [   1,    2,     3,      4,    5,            6,          7,  8,      9,  10]
            col1 = 2; % Col with A
            for i = 1:length(x_i)
                cc = c(i); % be careful here
                col_var = 1;
                % Var* = Var(-) + alfa*(Var(+) - Var(-))
                y(i+1,n) = var_middle(col_var,i,1) + alfa_var_middle(col_var,i)*(var_middle(col_var,i,2) - var_middle(col_var,i,1));
            end
        end
    end
    % Hydraulic Radius
    if flag_section ~= 4
        Rh_middle = Rh_function(D,Z1,Z2,a,b,y(x_i,n));
        % ybar
        ybar(x_i,n) = ybar_function(D,Z1,Z2,a,b,y(x_i,n));
        % f1 and f2
        f1(x_i,n) = q2(x_i,n);
        f2(x_i,n) = q2(x_i,n).*abs(q2(x_i,n))./q1(x_i,n) + g*q1(x_i,n).*ybar(x_i,n);
        % Froude
        Hm = A_function(D,Z1,Z2,a,b,y(x_i,n))./B_function(D,Z1,Z2,a,b,y(x_i,n));
        Fr(x_i,n)=abs(q2(x_i,n)./q1(x_i,n))./((g*Hm).^0.5);% Número de Froude
        % Courant
        Cn(x_i,n)=(abs(q2(x_i,n)./q1(x_i,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
        % Friction
        if flag_friction == 1
            J2(x_i,n) = g*q1(x_i,n).*(I0(x_i) - q2(x_i,n).*abs(q2(x_i,n).*nm(x_i).^2./(q1(x_i,n).^2.*Rh_middle.^(4/3))));
        else
            J2(x_i,n) = g*q1(x_i,n).*(I0(x_i) - f*q2(x_i,n).*abs(q2(x_i,n))./((q1(x_i,n).^2)*8*g*Rh_midle));
        end
        % Stability Check
        if max(Cn(:,n)) > 1
            error('Please, decrease the time-step')
        end
    else
        for jj = 1:length(x_i)
            cc = c(jj); % Area
            % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
            % [   1,    2,     3,      4,    5,            6,          7,  8,      9,  10]
            col_var = 4;
            % Var* = Var(-) + alfa*(Var(+) - Var(-))
            Rh_middle(jj,1) = var_middle(col_var,jj,1) + alfa_var_middle(col_var,jj)*(var_middle(col_var,jj,2) - var_middle(col_var,jj,1));
            col_var = 5;
            ybar(jj+1,n) = var_middle(col_var,jj,1) + alfa_var_middle(col_var,jj)*(var_middle(col_var,jj,2) - var_middle(col_var,jj,1));
            col_var = 6;
            nm(jj+1,1) = var_middle(col_var,jj,1) + alfa_var_middle(col_var,jj)*(var_middle(col_var,jj,2) - var_middle(col_var,jj,1));
            % f1 and f2
            f1(jj+1,n) = q2(jj+1,n);
            f2(jj+1,n) = q2(jj+1,n).*abs(q2(jj+1,n))./q1(jj+1,n) + g*q1(jj+1,n).*ybar(jj+1,n);
            % Froude
            A_f_irr = q1(jj+1,n);
            col_var = 9;
            B_f_irr = var_middle(col_var,jj,1) + alfa_var_middle(col_var,jj)*(var_middle(col_var,jj,2) - var_middle(col_var,jj,1));
            Hm = A_f_irr./B_f_irr;
            Fr(jj+1,n) = abs(q2(jj+1,n)./q1(jj+1,n))./((g*Hm).^0.5);% Número de Froude
            % Courant
            Cn(jj+1,n) = (abs(q2(jj+1,n)./q1(jj+1,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
            % Friction
            if flag_friction == 1
                J2(jj+1,n) = g*A_f_irr.*(I0(jj+1,1) - q2(jj+1,n).*abs(q2(jj+1,n).*nm(jj+1,1).^2./(A_f_irr.^2.*Rh_middle(jj,1)^(4/3))));
            else
                J2(jj+1,n) = g*q1(jj+1,n).*(I0(jj+1,n) - f*q2(jj+1,n).*abs(q2(jj+1,n))./((q1(jj+1,n).^2)*8*g*Rh_midle(jj,1)));
            end
            % Stability Check
            if Cn(jj+1,n) > 1
                error('Please, decrease the time-step')
            end
        end
    end
end

zzz = [y(ceil(Nx/2),:)', q2(ceil(Nx/2),:)',tint' , q2(1,:)'];
%%% Post Processing Figures %%%
% Call function
warning('on');
post_processing
toc



