%% Post Processing Graphs
clf
close all


% Surfplot
t_save = [0:Nat:tt/dt];
t_save(1,1) = 1;
set(gcf,'units','inches','position',[2,2,4,5])
subplot(3,1,1)
surf(x,tint(t_save)/60,Fr(:,t_save)');
view(0,90);
kk = colorbar ; colormap('jet')
shading interp
xlabel('x (m)','Interpreter','latex')
ylabel('t (h)','Interpreter','latex')
ylabel(kk,'Froude Number','Interpreter','latex')
zlabel ('Froude Number','Interpreter','Latex');
xlim([0 L]);
ylim([0 tt/60/60]);

subplot(3,1,2)
surf(x,tint(t_save)/60/60,y(:,t_save)');
view(0,90);
kk = colorbar ; colormap('jet')
shading interp
xlabel('x (m)','Interpreter','latex')
ylabel('t (h)','Interpreter','latex')
ylabel(kk,'y (m)','Interpreter','latex')
zlabel ('y (m)','Interpreter','Latex');
xlim([0 L]);
ylim([0 tf/60/60]);
subplot(3,1,3)
wse = y + inv_el;
surf(x,tint(t_save)/60/60,wse(:,t_save)');
view(0,90);
kk = colorbar ; colormap('jet')
shading interp
xlabel('x (m)','Interpreter','latex')
ylabel('t (h)','Interpreter','latex')
ylabel(kk,'WSE (m)','Interpreter','latex')
zlabel ('WSE (m)','Interpreter','Latex');
xlim([0 L]);
ylim([0 tf/60/60]);
exportgraphics(gcf,'Surf_Plots.pdf','ContentType','image','Colorspace','rgb','Resolution',600)
clf
close all

if flag_section == 2 % circular
% Video
obj = VideoWriter('Circular_Depth.avi','Motion JPEG AVI');
obj.Quality = 100;
obj.FrameRate = 20;
open(obj)
set(gcf,'units','inches','position',[2,2,10,3])
    for n=1:1:(Nt/Nat)
        if n == 1
            t = 1;
            pos = 1;
        else
            t=(n-1)*Nat*dt;
            pos = t/dt;
        end
        % Circle Function
        xcir = linspace(0,2*pi,100); % 100 points within 0 and 360 deg
        cir = @(r,ctr) [r*cos(xcir)+ctr(1); r*sin(xcir)+ctr(2)];                     
        c1 = cir(D/2, [D/2; D/2]);

        % Boundary Circle
        % (x - xc)^2 + (y - yc)^2 = D^2/4
        % where xc = D/2 and yc = D/2
        xc = D/2; yc = D/2;
        y01 = y(1,pos);
        y02 = y(ceil(ceil(Nx/2)),pos);
        y03 = y(Nx,pos);
        y0_c = [y01; y02; y03];
        % For a given known y, we have to find two xs, such that
        % x^2 + (-2xc)x + ( (y0 - yc)^2 - xc^2 - D^2/4 )
        % or ax^2 + bx + c, with
        % a = 1; b = -2xc; c = (y0 - yc)^2 - xc^2 - D^2/4
        % x = (- b +- sqrt(b^2 - 4ac)) / (2a)
        a = 1;
        b = -2*xc;
        c = xc^2 + (y0_c - yc).^2 - D^2/4;
        Delta = b^2 - 4*a.*c;
        x1 = (-b + sqrt(Delta))/(2*a);
        x2 = (-b - sqrt(Delta))/(2*a);
        % Now we found the intersection of the circle and a line with know
        % depth        
        subplot(1,3,1)
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
        ylim([0 D]);
        xlim([0 D]);
        viscircles([D/2 D/2],D/2,'Color','black');        
%         plot(c1(1,:),c1(2,:),'Color','black');
        hold on
        x_water = linspace(x2(1),x1(1),100);
        y_water = repmat(y01,1,100);
        plot(x_water,y_water,'blue','linewidth',2);
%         fill([c1(1,:) fliplr(c1(1,:))], [y_water fliplr(c2(1,:))],'blue') 
        ylabel('y(m)','Interpreter','latex')
        xlabel('B(m)','Interpreter','latex')
        legend('Entrance','interpreter','latex')        
        hold off
        % second section        
        subplot(1,3,2)
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
        ylim([0 D]);
        xlim([0 D]);        
        viscircles([D/2 D/2],D/2,'Color','black');
        hold on
        x_water = linspace(x2(2),x1(2),100);
        y_water = repmat(y02,1,100);
        plot(x_water,y_water,'blue','linewidth',2);  
        ylabel('y(m)','Interpreter','latex')
        xlabel('B(m)','Interpreter','latex')     
        legend('x = L/2','interpreter','latex')                
        hold off
        legend('L/2','interpreter','latex')        
        % third section        
        subplot(1,3,3)
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])        
        ylim([0 D]);
        xlim([0 D]);        
        viscircles([D/2 D/2],D/2,'Color','black');
        hold on
        x_water = linspace(x2(3),x1(3),100);
        y_water = repmat(y03,1,100);
        plot(x_water,y_water,'blue','linewidth',2);             hold off         
        ylabel('y(m)','Interpreter','latex')
        xlabel('B(m)','Interpreter','latex')        
        legend('Exit','interpreter','latex')
        % Save frame
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
        f = getframe(gcf);
        writeVideo(obj,f);
        hold off 
        clf
    end
obj.close();    
end

if flag_section == 3 % paraboloid
% Video
obj = VideoWriter('Parabolic_Depth.avi','Motion JPEG AVI');
obj.Quality = 100;
obj.FrameRate = 20;
open(obj)
set(gcf,'units','inches','position',[2,2,10,3])
    for n=1:1:(Nt/Nat)
        if n == 1
            t = 1;
            pos = 1;
        else
            t=(n-1)*Nat*dt;
            pos = t/dt;
        end
        % Parabolic Function
        % y = a*x^2 => xmax = sqrt((ymax/a))
        ymax = max(max(y));
        xmax = sqrt(ymax/a); % x to left and right directions
        xpar = linspace(-xmax,xmax,100); % 100 points within -xmax and xmax deg                     
        ypar = a.*xpar.^2;
        % Now we found bottom of the channel
        % We still need to find xleft and xright for a given y
        y01 = y(1,pos);
        y02 = y(ceil(Nx/2),pos);
        y03 = y(Nx,pos);
        y0_c = [y01; y02; y03];
        xright = sqrt(y0_c/a);
        xleft = - xright;
        subplot(1,3,1)
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
        ylim([0 ymax]);
        xlim([0 ymax]);
        plot(xpar,ypar,'Color','black');        
        hold on
        x_water = linspace(xleft(1),xright(1),100);
        y_water = linspace(y01,y01,100);
        plot(x_water,y_water,'blue','linewidth',2);
        ylabel('y(m)','Interpreter','latex')
        xlabel('B(m)','Interpreter','latex')
        legend('Entrance','interpreter','latex')        
        hold off
        % second section        
        subplot(1,3,2)
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
        ylim([0 ymax]);
        xlim([0 ymax]);
        plot(xpar,ypar,'Color','black');        
        hold on
        x_water = linspace(xleft(2),xright(2),100);
        y_water = linspace(y02,y02,100);
        plot(x_water,y_water,'blue','linewidth',2);
        ylabel('y(m)','Interpreter','latex')
        xlabel('B(m)','Interpreter','latex')
        legend('x = L/2','interpreter','latex')     
        hold off
        % third section        
        subplot(1,3,3)
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])        
        ylim([0 ymax]);
        xlim([0 ymax]);
        plot(xpar,ypar,'Color','black');        
        hold on
        x_water = linspace(xleft(3),xright(3),100);
        y_water = linspace(y03,y03,100);
        plot(x_water,y_water,'blue','linewidth',2);
        ylabel('y(m)','Interpreter','latex')
        xlabel('B(m)','Interpreter','latex')
        legend('Outlet','interpreter','latex')               
        % Save frame
        title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
        f = getframe(gcf);
        writeVideo(obj,f);
        hold off 
        clf
    end
obj.close();    
end


% Plots
set(gcf,'units','inches','position',[0,0,7,12])
subplot(3,2,1)
% Flows
plot(tint/60,q2(1,:),'LineStyle','--','LineWidth',2,'Color','k')
hold on
plot(tint/60,q2(ceil(Nx/2),:),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(tint/60,q2(Nx,:),'LineStyle','-','LineWidth',2,'Color','k')
hold on
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Flow Discharge (m\textsuperscript{3}/s)','Interpreter','latex');
legend('Entrance','L/2','Outlet','Interpreter','Latex','location','best')
% Velocity
subplot(3,2,2)
plot(tint/60,q2(1,:)./q1(1,:),'LineStyle','--','LineWidth',2,'Color','k')
hold on
plot(tint/60,q2(ceil(Nx/2),:)./q1(ceil(Nx/2),:),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(tint/60,q2(Nx,:)./q1(Nx,:),'LineStyle','-','LineWidth',2,'Color','k')
%%% Normal Depth Velocity %%%
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Velocity (m/s)','Interpreter','latex');
legend('Entrance','L/2','Outlet','Interpreter','Latex','Location','best')
% Water Depth
subplot(3,2,3)
plot(tint/60,y(1,:),'LineStyle','--','LineWidth',2,'Color','k')
hold on
plot(tint/60,y(ceil(Nx/2),:),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(tint/60,y(Nx,:),'LineStyle','-','LineWidth',2,'Color','k')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Water Depths (m)','Interpreter','latex');
legend('Entrance','L/2','Outlet','Interpreter','Latex','Location','best')
% Froude Number
subplot(3,2,4)
plot(tint/60,Fr(1,:),'LineStyle','--','LineWidth',2,'Color','k')
hold on
plot(tint/60,Fr(ceil(Nx/2),:),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(tint/60,Fr(Nx,:),'LineStyle','-','LineWidth',2,'Color','k')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Froude Number','Interpreter','latex');
legend('Entrance','L/2','Outlet','Interpreter','Latex','Location','best')

% Courant Number
subplot(3,2,5)
plot(tint/60,Cn(1,:),'LineStyle','--','LineWidth',2,'Color','k')
hold on
plot(tint/60,Cn(ceil(Nx/2),:),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(tint/60,Cn(Nx,:),'LineStyle','-','LineWidth',2,'Color','k')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Courant Number','Interpreter','latex');
legend('Entrance','L/2','Outlet','Interpreter','Latex','Location','best')

% Rating Curve
% Solving for normal Depth
ymin = min(min(y));
ymax = max(max(y));
y_m = [ymin:0.01:ymax]'; % meters
hs = 1; % half section
% hs = ceil(1);
if flag_section ~= 4
        Qn = 1/nm(hs).*A_function(D,Z1,Z2,a,b,y_m).*Rh_function(D,Z1,Z2,a,b,y_m).^(2/3).*I0(hs)^0.5;
else
    % [y_table, A, P, Rh, y_bar, n_med, Beta, v, B, Q]
    % [   1,    2, 3, 4,    5,    6,      7,  8,  9, 10]
    col1 = 2; % Col with A
    for jj = 1:length(q1(hs,:))
        Qn(jj,1) = Vlookup_g(irr_table,col1,q1(hs,jj),10); % Attention here
        y_m(jj,1) = Vlookup_g(irr_table,col1,q1(hs,jj),1);
        rh_i = Vlookup_g(irr_table,col1,q1(hs,jj),4);
    end
end
subplot(3,2,6)
tbegin = 30; % (steps), considering initial stabilization of the domain
plot(q2(hs,tbegin:end),y(hs,tbegin:end),'LineStyle','--','LineWidth',2,'Color','k')
hold on
plot(q2(ceil(Nx/2),tbegin:end),y(ceil(Nx/2),tbegin:end),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(Qn,y_m,'LineStyle','-','LineWidth',2,'Color','k')
xlabel('Flow Discharge (m\textsuperscript{3}/s)','Interpreter','latex');
ylabel('Water Depth (m)','Interpreter','latex');
ylim([ymin 1.1*max([max(y_m),max(y(ceil(Nx)))])]);
legend('Q(Inlet)','Q(Nx/2)','$Q_{n}$ (L)','Interpreter','Latex','Location','best')
hold off
exportgraphics(gcf,'Summary_Charts.pdf','ContentType','vector')
clf
close all

% Channel Width Chart
h_f = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'channel_width.gif';
B2 = zeros(size(q1));
if flag_section ~= 4
    B2 = B_function(D,Z1,Z2,a,b,y);
else
    for pos_b = 1:length(q1(:,1))
        for time_b = 1:length(q1(1,:))
            % [y_table, A, P, Rh, y_bar, n_med, Beta, v, B, Q]
            % [   1,    2, 3, 4,    5,    6,      7,  8,  9, 10]            
            B2(pos_b,time_b) = Vlookup_g(irr_table,col1,q1(pos_b,time_b),9);
        end
    end
end
for n=1:1:(Nt/Nat)
    if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    left_margin = B2(:,pos)/2; right_margin = -B2(:,pos)/2;
    plot(x,left_margin,'k','LineWidth',2);
    hold on
    plot(x,right_margin,'k','LineWidth',2);
    hold on
    fill([x' fliplr(x')],[right_margin' fliplr(left_margin')],'blue')
    xlabel('x [m]');
    ylabel('B [m]');
    ylim([1.1*min(min(-B2/2)), max(max(1.1*(B2/2)))]);
    grid on
    %legend('y(x,t)',2)
    title(['t = ',num2str(round(t/60,2)),' [min]'])
    drawnow
    % Capture the plot as an image
    frame = getframe(h_f);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if n == 1
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append');
    end
    hold off
end
clf
close all

% Water Depth Profile
h_f = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'channel_wse_profile.gif';
wse = inv_el + y; % water surface elevation in meters
for n=1:1:(Nt/Nat)
     if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    plot(x,inv_el,'LineWidth',4,'LineStyle','-','Color','k')
    hold on
    plot(x,wse(:,pos),'k','LineWidth',2,'LineStyle','-','Color','blue')
    fill([x' fliplr(x')], [inv_el' fliplr(wse(:,pos)')],'blue')
    xlabel('x [m]','Interpreter','latex');
    ylabel('Water surface Elevation [m]','Interpreter','latex');
    ylim([0.98*min(min(wse - y)) max(max(1.01*wse))])
    grid on
    %legend('y(x,t)',2)
    title(['t = ',num2str(round(t/60,2)),' [min]'])
    drawnow
    % Capture the plot as an image
    frame = getframe(h_f);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if n == 1
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append');
    end
    hold off
    %mov=addframe(mov,Mo); %Para gravar o vídeo, não comentar (excluir %)
end
close all
% 3D Channel Water Surface Elevation

% Video
obj = VideoWriter('WSE.avi','Motion JPEG AVI');
obj.Quality = 100;
obj.FrameRate = 20;
open(obj)
for n=1:1:(Nt/Nat)
    if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    plot(x,inv_el,'LineWidth',4,'LineStyle','-','Color','k')
    hold on
    plot(x,wse(:,pos),'k','LineWidth',2,'LineStyle','-','Color','blue')
    fill([x' fliplr(x')], [inv_el' fliplr(wse(:,pos)')],'blue')
    xlabel('x [m]','Interpreter','latex');
    ylabel('Water surface Elevation [m]','Interpreter','latex');
    ylim([0.98*min(min(wse - y)) max(max(1.01*wse))])
    grid on
    title(['t = ',num2str(round(round(t/60,2),2)),' [min]'])
    f = getframe(gcf);
    writeVideo(obj,f);
    hold off
end
obj.close();

%% Ploting Irregular Cross-section
% Cross-section Depths
% Water Depth Profile
% Video
%%%%%%%%%%% Figure Without Fill %%%%%%%%%%%%%%%%%
% sm = (1e-8 + 1);
% obj = VideoWriter('Cross_section_outlet.avi','Motion JPEG AVI');
% obj.Quality = 100;
% obj.FrameRate = 20;
% open(obj)
% set(gcf,'units','inches','position',[2,0,6.5,8])
% for n=1:1:(Nt/Nat)
%     if n == 1
%         t = 1;
%     else
%         t=(n-1)*Nat*dt;
%     end  
%     subplot(3,1,1)
%     pos = Nx; % Position where the Plots will be made (Outlet)
%     y_cs = [y(pos,t) y(pos,t)]; % Vector of Water Depth (m)  
%     plot(x_cross,y_cross,'LineWidth',1.5,'Color','k') % Plotting Cross-Section
%     hold on
%     scatter(x_cross,y_cross,'o','b') % Plotting Break Points
%     % Determine x_inv e y_inv
%     min_el = min(y_cross); % Minimum elevation (m)
%     pos_inv = find(y_cross == min_el); % Position where it occurs
%     x_inv = x_cross(pos_inv); y_inv = y_cross(pos_inv); % x coordinate of invert (m)
%     % Determine x_left
%     x_left_unsorted = x_cross(1:(pos_inv-1),1);  % Left values of x
%     y_left_unsorted = y_cross(1:(pos_inv-1),1); % Right values of x
%     pos_left_up = find(y_left_unsorted>sm*y_cs(1),1,'last'); % left postion with y > ym
%     pos_left_down = (pos_left_up + 1); % down postion of y > ym
%     % x and y for left points
%     x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
%     x_left_down = x_left_unsorted(pos_left_down,1); % x(m)
%     y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
%     y_left_down = y_left_unsorted(pos_left_down,1); % y(m)
%     alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
%     dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth 
%     x_begin = x_left_down - dy/alfa_l; % Intersection with left bank
%     x_end = x_begin + B2(pos,t); % Intersection with right bank
%     x_b = [x_begin x_end]; % Vector of x
%     plot(x_b,y_cs,'b','LineWidth',2); % Plot of top-width
%     hold off
%     grid on
%     xlabel('x(m)','Interpreter','latex')
%     ylabel('y(m)','Interpreter','latex')        
%     title(['Inlet (t) = ',num2str(round(round(t/60,2),2)),' [min]'])
% 
%     subplot(3,1,2)
%     pos = ceil(Nx/2); % Position where the Plots will be made (Half)
%     y_cs = [y(pos,t) y(pos,t)]; % Vector of Water Depth (m)  
%     plot(x_cross,y_cross,'LineWidth',1.5,'Color','k') % Plotting Cross-Section
%     hold on
%     scatter(x_cross,y_cross,'o','b') % Plotting Break Points
%     % Determine x_inv e y_inv
%     min_el = min(y_cross); % Minimum elevation (m)
%     pos_inv = find(y_cross == min_el); % Position where it occurs
%     x_inv = x_cross(pos_inv); y_inv = y_cross(pos_inv); % x coordinate of invert (m)
%     % Determine x_left
%     x_left_unsorted = x_cross(1:(pos_inv-1),1);  % Left values of x
%     y_left_unsorted = y_cross(1:(pos_inv-1),1); % Right values of x
%     pos_left_up = find(y_left_unsorted>sm*y_cs(1),1,'last'); % left postion with y > ym
%     pos_left_down = (pos_left_up + 1); % down postion of y > ym
%     % x and y for left points
%     x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
%     x_left_down = x_left_unsorted(pos_left_down,1); % x(m)
%     y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
%     y_left_down = y_left_unsorted(pos_left_down,1); % y(m)
%     alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
%     dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth 
%     x_begin = x_left_down - dy/alfa_l; % Intersection with left bank
%     x_end = x_begin + B2(pos,t); % Intersection with right bank
%     x_b = [x_begin x_end]; % Vector of x
%     plot(x_b,y_cs,'b','LineWidth',2); % Plot of top-width
%     hold off
%     grid on
%     xlabel('x(m)','Interpreter','latex')
%     ylabel('y(m)','Interpreter','latex')        
%     title(['L/2 (t) = ',num2str(round(round(t/60,2),2)),' [min]'])   
% 
%     subplot(3,1,3)
%     pos = Nx; % Position where the Plots will be made (Half)
%     y_cs = [y(pos,t) y(pos,t)]; % Vector of Water Depth (m)  
%     plot(x_cross,y_cross,'LineWidth',1.5,'Color','k') % Plotting Cross-Section
%     hold on
%     scatter(x_cross,y_cross,'o','b') % Plotting Break Points
%     % Determine x_inv e y_inv
%     min_el = min(y_cross); % Minimum elevation (m)
%     pos_inv = find(y_cross == min_el); % Position where it occurs
%     x_inv = x_cross(pos_inv); y_inv = y_cross(pos_inv); % x coordinate of invert (m)
%     % Determine x_left
%     x_left_unsorted = x_cross(1:(pos_inv-1),1);  % Left values of x
%     y_left_unsorted = y_cross(1:(pos_inv-1),1); % Right values of x
%     pos_left_up = find(y_left_unsorted>sm*y_cs(1),1,'last'); % left postion with y > ym
%     pos_left_down = (pos_left_up + 1); % down postion of y > ym
%     % x and y for left points
%     x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
%     x_left_down = x_left_unsorted(pos_left_down,1); % x(m)
%     y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
%     y_left_down = y_left_unsorted(pos_left_down,1); % y(m)
%     alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
%     dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth 
%     x_begin = x_left_down - dy/alfa_l; % Intersection with left bank
%     x_end = x_begin + B2(pos,t); % Intersection with right bank
%     x_b = [x_begin x_end]; % Vector of x
%     plot(x_b,y_cs,'b','LineWidth',2); % Plot of top-width
%     hold off
%     grid on
%     xlabel('x(m)','Interpreter','latex')
%     ylabel('y(m)','Interpreter','latex')        
%     title(['L (t) = ',num2str(round(round(t/60,2),2)),' [min]'])       
% 
%     % Writting Video
%     f = getframe(gcf);
%     writeVideo(obj,f);
%     hold off 
%     clf    
% 
% end
% close all
if flag_section == 4
sm = (1e-8 + 1);
obj = VideoWriter('Cross_section_outlet.avi','Motion JPEG AVI');
obj.Quality = 100;
obj.FrameRate = 5;
open(obj)
set(gcf,'units','inches','position',[2,0,6.5,8])
for n=1:1:(Nt/Nat)
    if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    subplot(3,1,1)
    pos_x = Nx; % Position where the Plots will be made (Inlet)
    y_cs = [y(pos_x,pos) y(pos_x,pos)]; % Vector of Water Depth (m)  
    plot(x_cross,y_cross,'LineWidth',1.5,'Color','k') % Plotting Cross-Section
    hold on
    scatter(x_cross,y_cross,'o','b') % Plotting Break Points
    % Determine x_inv e y_inv
    min_el = min(y_cross); % Minimum elevation (m)
    pos_inv = find(y_cross == min_el); % Position where it occurs
    x_inv = x_cross(pos_inv); y_inv = y_cross(pos_inv); % x coordinate of invert (m)
    % Determine x_left
    x_left_unsorted = x_cross(1:(pos_inv-1),1);  % Left values of x
    y_left_unsorted = y_cross(1:(pos_inv-1),1); % Right values of x
    y_right_unsorted = y_cross(pos_inv + 1:end,1); % Right values of x
    x_right_unsorted = x_cross(pos_inv + 1:end,1); % Right values of x
    pos_left_up = find(y_left_unsorted>sm*y_cs(1),1,'last'); % left postion with y > ym
    if pos_left_up == length(y_left_unsorted)
        pos_left_down = pos_left_up;
        x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
        x_left_down = x_inv;
        y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
        y_left_down = y_inv;
        alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
        dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth            
    else
       pos_left_down = (pos_left_up + 1); % down postion of y > ym
        % x and y for left points
        x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
        x_left_down = x_left_unsorted(pos_left_down,1); % x(m)
        y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
        y_left_down = y_left_unsorted(pos_left_down,1); % y(m)
        alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
        dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth        
    end
    pos_right_end = find(y_right_unsorted>sm*y_cs(1),1,'first'); % left postion with y > ym
    
    if isnan(alfa_l)
        x_begin = x_left_down;
    else
        x_begin = x_left_down - dy/alfa_l; % Intersection with left bank
    end
    x_end = x_begin + B2(pos_x,pos); % Intersection with right bank
    x_b = [x_begin x_end]; % Vector of x
    plot(x_b,y_cs,'b','LineWidth',2); % Plot of top-width
    x_flip = linspace(x_b(1,1),x_b(1,2),length(x_cross))';
    %%%
    y_section = [y_cs(1,1) ; y_left_unsorted(pos_left_up:end,1); y_inv; y_right_unsorted(1:(pos_right_end));y_cs(1,2)];
    x_section = [x_b(1,1) ; x_left_unsorted(pos_left_up:end,1); x_inv; x_right_unsorted(1:(pos_right_end));x_b(1,2)];    
%     y_section = linspace(y_cs(1,1),y_cs(1,2),length(x_cross))';
    %%%
    y_flip = linspace(y_cs(1,1),y_cs(1,2),length(y_section))';    
    p = fill([x_section' fliplr(x_section')],[y_section' fliplr(y_flip')],'blue');
    p.EdgeColor = [1 1 1];
    hold off
    grid on
    xlabel('x(m)','Interpreter','latex')
    ylabel('y(m)','Interpreter','latex') 
    xlim([min(x_cross) max(x_cross)])
    title(['Outlet (t) = ',num2str(round(round(t/60,2),2)),' [min]'])

    subplot(3,1,2)
    pos_x = ceil(Nx/2); % Position where the Plots will be made (Inlet)
    y_cs = [y(pos_x,pos) y(pos_x,pos)]; % Vector of Water Depth (m)  
    plot(x_cross,y_cross,'LineWidth',1.5,'Color','k') % Plotting Cross-Section
    hold on
    scatter(x_cross,y_cross,'o','b') % Plotting Break Points
    % Determine x_inv e y_inv
    min_el = min(y_cross); % Minimum elevation (m)
    pos_inv = find(y_cross == min_el); % Position where it occurs
    x_inv = x_cross(pos_inv); y_inv = y_cross(pos_inv); % x coordinate of invert (m)
    % Determine x_left
    x_left_unsorted = x_cross(1:(pos_inv-1),1);  % Left values of x
    y_left_unsorted = y_cross(1:(pos_inv-1),1); % Right values of x
    y_right_unsorted = y_cross(pos_inv + 1:end,1); % Right values of x
    x_right_unsorted = x_cross(pos_inv + 1:end,1); % Right values of x
    pos_left_up = find(y_left_unsorted>sm*y_cs(1),1,'last'); % left postion with y > ym
    if pos_left_up == length(y_left_unsorted)
        pos_left_down = pos_left_up;
        x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
        x_left_down = x_inv;
        y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
        y_left_down = y_inv;
        alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
        dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth            
    else
       pos_left_down = (pos_left_up + 1); % down postion of y > ym
        % x and y for left points
        x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
        x_left_down = x_left_unsorted(pos_left_down,1); % x(m)
        y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
        y_left_down = y_left_unsorted(pos_left_down,1); % y(m)
        alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
        dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth        
    end
    pos_right_end = find(y_right_unsorted>sm*y_cs(1),1,'first'); % left postion with y > ym
    
    if isnan(alfa_l)
        x_begin = x_left_down;
    else
        x_begin = x_left_down - dy/alfa_l; % Intersection with left bank
    end
    x_end = x_begin + B2(pos_x,pos); % Intersection with right bank
    x_b = [x_begin x_end]; % Vector of x
    plot(x_b,y_cs,'b','LineWidth',2); % Plot of top-width
    x_flip = linspace(x_b(1,1),x_b(1,2),length(x_cross))';
    %%%
    y_section = [y_cs(1,1) ; y_left_unsorted(pos_left_up:end,1); y_inv; y_right_unsorted(1:(pos_right_end));y_cs(1,2)];
    x_section = [x_b(1,1) ; x_left_unsorted(pos_left_up:end,1); x_inv; x_right_unsorted(1:(pos_right_end));x_b(1,2)];    
%     y_section = linspace(y_cs(1,1),y_cs(1,2),length(x_cross))';
    %%%
    y_flip = linspace(y_cs(1,1),y_cs(1,2),length(y_section))';    
    p = fill([x_section' fliplr(x_section')],[y_section' fliplr(y_flip')],'blue');
    p.EdgeColor = [1 1 1];
    hold off
    grid on
    xlabel('x(m)','Interpreter','latex')
    ylabel('y(m)','Interpreter','latex') 
    xlim([min(x_cross) max(x_cross)])
    title(['L/2 (t) = ',num2str(round(round(t/60,2),2)),' [min]'])

    subplot(3,1,3)
    pos_x = Nx; % Position where the Plots will be made (Inlet)
    y_cs = [y(pos_x,pos) y(pos_x,pos)]; % Vector of Water Depth (m)  
    plot(x_cross,y_cross,'LineWidth',1.5,'Color','k') % Plotting Cross-Section
    hold on
    scatter(x_cross,y_cross,'o','b') % Plotting Break Points
    % Determine x_inv e y_inv
    min_el = min(y_cross); % Minimum elevation (m)
    pos_inv = find(y_cross == min_el); % Position where it occurs
    x_inv = x_cross(pos_inv); y_inv = y_cross(pos_inv); % x coordinate of invert (m)
    % Determine x_left
    x_left_unsorted = x_cross(1:(pos_inv-1),1);  % Left values of x
    y_left_unsorted = y_cross(1:(pos_inv-1),1); % Right values of x
    y_right_unsorted = y_cross(pos_inv + 1:end,1); % Right values of x
    x_right_unsorted = x_cross(pos_inv + 1:end,1); % Right values of x
    pos_left_up = find(y_left_unsorted>sm*y_cs(1),1,'last'); % left postion with y > ym
    if pos_left_up == length(y_left_unsorted)
        pos_left_down = pos_left_up;
        x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
        x_left_down = x_inv;
        y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
        y_left_down = y_inv;
        alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
        dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth            
    else
       pos_left_down = (pos_left_up + 1); % down postion of y > ym
        % x and y for left points
        x_left_up = x_left_unsorted(pos_left_up,1); % x(m)
        x_left_down = x_left_unsorted(pos_left_down,1); % x(m)
        y_left_up = y_left_unsorted(pos_left_up,1); % y(m)
        y_left_down = y_left_unsorted(pos_left_down,1); % y(m)
        alfa_l = (y_left_up - y_left_down)/(abs(x_left_up - x_left_down)); % Left angle
        dy = (abs(y_cs(1,1) - y_left_down)); % Difference in water depth        
    end
    pos_right_end = find(y_right_unsorted>sm*y_cs(1),1,'first'); % left postion with y > ym
    
    if isnan(alfa_l)
        x_begin = x_left_down;
    else
        x_begin = x_left_down - dy/alfa_l; % Intersection with left bank
    end
    x_end = x_begin + B2(pos_x,pos); % Intersection with right bank
    x_b = [x_begin x_end]; % Vector of x
    plot(x_b,y_cs,'b','LineWidth',2); % Plot of top-width
    x_flip = linspace(x_b(1,1),x_b(1,2),length(x_cross))';
    %%%
    y_section = [y_cs(1,1) ; y_left_unsorted(pos_left_up:end,1); y_inv; y_right_unsorted(1:(pos_right_end));y_cs(1,2)];
    x_section = [x_b(1,1) ; x_left_unsorted(pos_left_up:end,1); x_inv; x_right_unsorted(1:(pos_right_end));x_b(1,2)];    
%     y_section = linspace(y_cs(1,1),y_cs(1,2),length(x_cross))';
    %%%
    y_flip = linspace(y_cs(1,1),y_cs(1,2),length(y_section))';    
    p = fill([x_section' fliplr(x_section')],[y_section' fliplr(y_flip')],'blue');
    p.EdgeColor = [1 1 1];
    hold off
    grid on
    xlabel('x(m)','Interpreter','latex')
    ylabel('y(m)','Interpreter','latex')  
    xlim([min(x_cross) max(x_cross)])
    title(['Inlet (t) = ',num2str(round(round(t/60,2),2)),' [min]'])

    % Writting Video
    f = getframe(gcf);
    writeVideo(obj,f);
    hold off 
    clf
end
end
obj.close();
close all



