%%% --------- HyProSWE Model ----------- %%%
% Script to read input data
% Developer: Marcus Nobrega Gomes Junior
% 5/1/2023
% Goal: Solution of 1-D SVE for given cross-section functions of Area, Perimeter, and
% top Width
% If you have any issues, please contact me at
% marcusnobrega.engcivil@gmail.com

% ---------- Please, don't change anything below ------------ %

%% Read Input Data %%
data = readtable('HyProSWE_Input_Data.xlsx','Sheet','Input_Data');
b = 0; Z1 = 0; Z2 = 0; a = 0; D = 0;


% General Data
general_data = table2array(data(1:16,2));
L = general_data(1,1);
Nx = general_data(2,1);
el = general_data(3,1);
g = general_data(4,1);
nm = general_data(5,1);
I0 = general_data(6,1);
tf = general_data(7,1);
dt = general_data(8,1);
animation_time = general_data(9,1);
s_outlet = general_data(10,1);
dh = general_data(11,1);
alpha = general_data(12,1);
dtmin = general_data(13,1);
dtmax = general_data(14,1);


% Flags
flags = table2array(data(19:29,2));
flag_hydrograph = flags(1,1);
flag_outlet = flags(2,1);
flag_friction = flags(3,1);
flag_section = flags(4,1);
flag_stage_hydrograph = flags(5,1);
flag_nash = flags(6,1);
flag_slope = flags(7,1);
flag_elevation = flags(8,1);
flag_output = flags(9,1);
flag_plot_HP = flags(10,1);
flag_elapsed_time = flags(11,1);
if flag_elapsed_time ~= 1
    Date_Begin = general_data(15,1);
    Date_Begin = datetime(datestr(Date_Begin+datenum('30-Dec-1899')));
    Date_End = general_data(16,1);
    Date_End = datetime(datestr(Date_End+datenum('30-Dec-1899')));    
end

if flag_nash == 1
    nash_data = table2array(data(1:4,5));
    % Hydrograph
    Tp = nash_data(1,1);
    Qb = nash_data(2,1);
    Beta = nash_data(3,1);
    Qp = nash_data(4,1);
else
    % Input Hydrograph
    input_hydrograph_data = table2array(data(8:end,4:5));
    time_ = input_hydrograph_data(1:end,1);
    Qe1_ = input_hydrograph_data(1:end,2);
    Qe1 = zeros(size(Qe1_,1) - sum(isnan(Qe1_)),1);
    time = zeros(size(time_,1) - sum(isnan(time_)),1);
    % Taking away nans
    for i = 1:length(Qe1)
        if isnan(Qe1_(i)) || isnan(time_(i))
            break
        else
            Qe1(i,1) = Qe1_(i,1);
            time(i,1) = time_(i,1);
        end
    end
    clear Qe1_ time_
end

if flag_stage_hydrograph ~= 0
    % Stage Hydrograph
    input_stage_data = table2array(data(8:end,7:8));
    time_stage_ = input_stage_data(1:end,1);
    he1_ = data(1:end,2);
    he1 = zeros(size(he1_,1) - sum(isnan(he1_)),1);
    time_stage = zeros(size(time_stage_,1) - sum(isnan(time_stage_)),1);
    % Taking away nans
    for i = 1:length(he1)
        if isnan(he1_(i)) || isnan(time_stage_(i))
            break
        else
            he1(i,1) = he1_(i,1);
            time_stage(i,1) = time_stage_(i,1);
        end
    end
    clear Qe1_ time_stage_
end

if flag_slope ~= 0
    % Slope
    input_slope_data = table2array(data(8:end,7:8));
    station = input_slope_data(1:end,1);
    bottom_slope = input_slope_data(2:end,2);
    slopes_not_nan = zeros(size(bottom_slope,1) - sum(isnan(bottom_slope)),1);
    station_index = zeros(size(station,1) - sum(isnan(station)),1);
    % Taking away nans
    for i = 1:length(station_index)
        if isnan(bottom_slope(i)) || isnan(station(i))
            break
        else
            slopes_not_nan(i,1) = bottom_slope(i,1);
            station_index(i,1) = station(i,1);
        end
    end
    clear station_index station bottom_slope
    bottom_slope = slopes_not_nan;
end

if flag_elevation ~= 0
    % Slope
    input_slope_data = table2array(data(8:end,7:8));
    station = input_slope_data(1:end,1);
    elevation_cell = table2array(data(8:end,7:8));
    inv_el_ = zeros(size(elevation_cell,1) - sum(isnan(elevation_cell)),1);
    station_index = zeros(size(station,1) - sum(isnan(station)),1);
    % Taking away nans
    for i = 1:length(station_index)
        if isnan(elevation_cell(i)) || isnan(station(i))
            break
        else
            inv_el_(i,1) = elevation_cell(i,1);
            station_index(i,1) = station(i,1);
        end
    end
    inv_el = inv_el_; % Invert Elevation
    clear station_index station elevation_cell inv_el_
end

% Outlet
if flag_outlet ~=1
    input_slope_wave = table2array(data(8:5,8));
    h_0_wave = input_slope_wave(1,1);
    H_0_wave = input_slope_wave(2,1);
    L_wave = input_slope_wave(3,1);
    T_wave = input_slope_wave(4,1);
    x_wave = input_slope_wave(5,1);
end

% Section
if flag_section == 1
    input_slope_trapezoid = table2array(data(1:3,11));
    b = input_slope_trapezoid(1,1);
    Z1 = input_slope_trapezoid(2,2);
    Z2 = input_slope_trapezoid(3,3);
elseif flag_section == 2
    input_slope_circular = table2array(data(1,14));
    D = input_slope_circular(1,1);
elseif flag_section == 3
    input_slope_parabolic = table2array(data(3,14));
    a = data(1,1);
else
    % Read HP estimator data
    [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr, x_cross, y_cross,s0] = HP_estimator(flag_plot_HP,dh);
    irr_table = [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];

    % Some Boundary Conditions
    % [y_irr, A_irr, P_irr, Rh_irr, y_bar_irr, n_med_irr, Beta_irr, u_irr, B_irr, Q_irr];
    % [   1,    2,     3,      4,    5,            6,          7,  8,      9,  10]
    irr_table(1,6) = irr_table(2,6); irr_table(1,7) = 0; irr_table(1,8) = 0;
    % Second Line
    irr_table(2,2) = 0; irr_table(2,3) = 0; irr_table(2,4) = 0; irr_table(2,5) = 0; irr_table(2,7) = 0; irr_table(2,8) = 0; irr_table(2,9) = 0; 
%     z = irr_table;
%     second = 0*z(2,:);
%     second(1,1) = 0.5*10^-3; second(1,6) = z(1,6); second(1,10) = z(1,10)/2;
%     z = [z(1,:) ; second; z(2:end,:)];
%     irr_table = z;
end


% Contraint at observed flow
if flag_hydrograph == 1
    if max(time) ~= tf
        z = round(tf - max(time),0);
        for i = 1:z
            Qe1(end + 1,1) = 0;
            time(end+1,1) = time(end,1) + 1;
        end
    end
end


% Contraint at stage hydrograph
if flag_stage_hydrograph == 1
    if max(time_stage) ~= tf
        z = round(tf - max(time_stage),0);
        for i = 1:z
            he1(end + 1,1) = 0;
            time_stage(end+1,1) = time_stage(end,1) + 1;
        end
    end
end

