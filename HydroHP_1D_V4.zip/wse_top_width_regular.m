% Post-Processing Routine
% Model: HyPro-SWE
% Developer: Marcus Nobrega
% Last Update: 4/29/2023
% Goal: Create animations of WSE and Top Width for regular sections

close all

Video_Name = 'WSE_Top_Width.avi';

% Set up video
video = VideoWriter(Video_Name,'MPEG-4');
open(video);

% Define water depths for each time
depths = Depth(:,1)';

% Preallocate Top Width
B2 = zeros(size(Flow_Area));

% Time
t = time_save; % Sec

% Define tick size
ticksize = [0.02 0.01];



% Water Surface Elevation
wse = Depth + repmat(inv_el',[size(Depth,1),1]);

% Color
color_plot = [21, 179, 196]/255;
set(gcf,'units','inches','position',[2,0,8,10])

% Iterate through all time steps
set(gca,'FontSize',14,'FontName','Garamond')
for i=1:length(t)
    Plot_Title = 'Time = %d (sec)';
    sgtitle(sprintf(Plot_Title, time_store(i)),'fontsize',18,'interpreter','latex')    
        % --------------- Plotting Channel Width ----------------- %
    subplot(2,3,[1 2 3]);
    if flag_section ~= 4
        B2 = B_function(D,Z1,Z2,a,b,Depth);
    else
        for pos_b = 1:length(Flow_Area(1,:))
            % [y_table, A, P, Rh, y_bar, n_med, Beta, v, B, Q]
            % [   1,    2, 3, 4,    5,    6,      7,  8,  9, 10]
            B2(i,pos_b) = Vlookup_g(irr_table,col1,Flow_Area(i,pos_b),9);
        end
    end
    if flag_section == 1
         offset = b/2 + (Z1 + Z2)/2*max(max(depths));
         xmax_plot = (Z1 + Z2)*max(max(depths)) + b;
    elseif flag_section == 2
        offset = D/2;
        xmax_plot = D;
    elseif flag_section == 3
        offset = xmax/2;
        xmax_plot = xmax;
    else
        offset = max(x_cross)/2; % From station data
        xmax_plot = max(x_cross);
    end
    right_margin = B2(i,:)/2 + offset; left_margin = -B2(i,:)/2 + offset;
    plot(x,right_margin,'k','LineWidth',2); set(gca,'YDir','reverse');
    hold on
    plot(x,left_margin,'k','LineWidth',2); set(gca,'YDir','reverse');
    hold on
    fill([x' fliplr(x')], [left_margin fliplr(right_margin)],color_plot)
    xlabel('$x$ [m]','Interpreter','latex');
    ylabel('Station [m]','Interpreter','latex');
    ylim([0, xmax_plot]);
    xlim([0, max(x)]);
    grid on
    title(sprintf('$B_{{max}}(t)$ = %.2f m', max(right_margin - left_margin)),'fontsize',16,'interpreter','latex');
    set(gca,'FontSize',12,'FontName','Garamond')
    
    % ---------------------  Ploting Water Surface Elevation ------- %
    subplot(2,3,[4 5 6])
    plot(x,inv_el,'LineWidth',4,'LineStyle','-','Color','k');
    hold on
    plot(x,wse(i,:),'k','LineWidth',2,'LineStyle','-','Color',color_plot);
    fill([x' fliplr(x')], [inv_el' fliplr(wse(i,:))],color_plot)
    xlabel('$x$ [m]','Interpreter','latex');
    ylabel('Water Surface Elevation [m]','Interpreter','latex');
    ylim([0.98*min(min(wse - Depth)) max(max(1.01*wse))])
    grid on
    title(sprintf('$WSE_{{max}}(t)$ = %.2f m', max(wse(i,:))),'fontsize',16,'interpreter','latex');

    % Save the frame for the video
    set(gca,'FontSize',12,'FontName','Garamond')
    % Set background color and write to video
    frame = getframe(gcf);
    writeVideo(video,frame);
    hold off
end
% Close video writer
close(video);
close all